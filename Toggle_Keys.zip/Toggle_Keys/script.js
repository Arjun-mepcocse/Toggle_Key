const buttons = document.querySelectorAll(".tab-btn");
const panels = document.querySelectorAll(".tab-content");

buttons.forEach(function (button) {
    button.addEventListener("click", function () {

        // 1. Remove 'active' from all buttons and panels
        buttons.forEach(function (b) { b.classList.remove("active"); });
        panels.forEach(function (p) { p.classList.remove("active"); });

        // 2. Add 'active' to the clicked button
        button.classList.add("active");

        // 3. Show the panel whose id matches data-tab
        const tabId = button.getAttribute("data-tab");
        document.getElementById(tabId).classList.add("active");
    });
});